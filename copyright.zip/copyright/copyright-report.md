# Part 1:

## How does the platform detect copyrighted content? (automated systems like Content ID, manual reporting, etc.)

Instagram (via Meta) uses automated matching tools to identify copyrighted audio, video, and images, primarily through Rights Manager, which allows rights holders to upload reference files and detect matches across Facebook and Instagram (https://www.facebook.com/rights_manager)

Instagram also refers to an internal Content ID–style system for detecting copyrighted material, especially music and video 

Copyright owners (or authorized agents) can also manually report infringing content using Instagram’s Copyright Report Form.

## What happens when content is flagged as potentially infringing?

If content is identified as infringing (via automated detection or a rights-holder report), Instagram may remove the post, block it in certain regions, or restrict visibility.

The user who posted the content is notified, and the removal is logged as a copyright strike.

Repeated copyright violations may result in account restrictions or permanent account disablement.

## What is the appeals or counter-notification process?

If you believe your content was removed in error, Instagram allows you to submit an appeal directly from the notification you receive.

If the content was removed under the DMCA, you may submit a counter-notification asserting lawful use (e.g., fair use, license, or ownership).

If the rights holder does not file a lawsuit within the DMCA’s required timeframe, Instagram may restore the content.

## How does the platform handle monetization of content containing copyrighted material?

Content that is unoriginal or reuses copyrighted material without meaningful transformation is generally ineligible for monetization on Meta platforms, including Instagram.

Instagram’s licensed music library allows creators to add music to content, but this does not grant monetization rights, especially for commercial or branded use.

Business and creator accounts are often directed to use Meta Sound Collection for music that is cleared for commercial and monetized use.

## Are there any special programs (e.g., YouTube's Content ID licensing agreements)?

Instagram does not offer a creator-facing revenue-sharing system equivalent to YouTube’s Content ID claims model.

Instead, Meta provides Rights Manager, which is designed for rights holders, not general creators, to:

- Detect matches  
- Block, monitor, or report infringing content  
- Protect original uploads  

Instagram also offers Content Protection tools to help creators prevent unauthorized reuploads of their original work.

# Part 2:

## For the raw copyrighted clip experiment, I uploaded two videos:

### 1. A 5 second clip of the Delicate music video by Taylor Swift

![Successful Upload](files/IMG_9096.PNG)

Time until detection: never detected

Final outcome: as of now, the content is still up

### A minute-long clip of the Delicate music video by Taylor Swift

![Successful Upload](files/IMG_9098.PNG)

Time until detection: under 1 hour

![Warning](files/IMG_9111.PNG)

Final outcome: video blocked in 249 territories, identified copyrighted video and audio owned by UMG

Options:

Submit a dispute if you have permission to use all of the content in your video. By submitting a dispute, you give UMG, who has issued this claim, permission to review your video. They can also review the entire post, if you’ve shared it publicly. They will have seven days to respond.

Delete this video to remove the video and any comments from your account. This content issue was detected automatically, and this action may have been automatically applied by the rights holder after your upload matched their reference file.

## For the commentary or criticism portion, I did a 1 minute-long voiceover analysing the music video, with the music still playing faintly in the background.

![Successful Upload](files/IMG_9101.PNG)

Time until detection: under 1 hour

![Warning](files/IMG_9110.PNG)

Final outcome: video blocked in 249 territories, identified copyrighted video and audio owned by UMG

Options:

Submit a dispute if you have permission to use all of the content in your video. By submitting a dispute, you give UMG, who has issued this claim, permission to review your video. They can also review the entire post, if you’ve shared it publicly. They will have seven days to respond.

Delete this video to remove the video and any comments from your account. This content issue was detected automatically, and this action may have been automatically applied by the rights holder after your upload matched their reference file.

# AI-Generated Content Investigation

## 1. Direct reference: In the style of Delicate (I couldn’t include the artists’ name in the prompt, but the song still does seem derivative of Delicate by Taylor Swift)

![Output](files/Screenshot 2025-12-13 at 7.35.12 AM.png)

![Successful Upload](files/IMG_9104.PNG)

As of now, no platform response.

## 2. Original creation: a bossa nova song about cats in Portuguese

![Output](files/Screenshot 2025-12-13 at 7.35.17 AM.png)

![Successful Upload](files/IMG_9105.PNG)

As of now, no platform response.

## Research findings on copyright ownership and policies

### What does Suno’s terms of service say about copyright?

Suno states that users retain ownership of the content they generate, to the extent permitted by law, but they grant Suno a broad license to use, host, reproduce, and distribute that content to operate and improve the service. Suno also disclaims responsibility for ensuring that outputs do not infringe third-party rights, placing that responsibility on users.  
(https://suno.ai/terms)

### Who owns the copyright to AI-generated content? (you, the AI company, the creators of training data, public domain/no one?)

According to Suno, the user owns the output, subject to applicable law, meaning ownership may be limited or nonexistent in jurisdictions that require human authorship for copyright protection. Suno does not claim ownership, and the creators of the training data do not receive rights in generated outputs; if no human authorship is recognized, the work may effectively be uncopyrightable.  
(https://suno.ai/terms)  
(https://www.copyright.gov/ai/)

### What is your platform's stated policy on AI-generated content?

Instagram’s stated policy is that AI-generated or AI-altered content is allowed, but it must be transparent and not deceptive. Instagram says it will label AI-generated images, video, and audio when it can detect them (using metadata or watermarks), and it requires creators to disclose AI use when content could mislead people, especially for realistic depictions of people or events. AI content is still subject to Instagram’s Community Standards, meaning deceptive deepfakes, impersonation, or harmful misinformation can be removed.

# 4. Legal Analysis

## Fair Use Four Factors

### Purpose and character of the use (transformative? commercial?)

The raw uploads of the Delicate music video were not transformative: they consisted of direct excerpts of the original audiovisual work with no added commentary, critique, or new meaning. The commentary/criticism video, by contrast, was more plausibly transformative, as it added spoken analysis and attempted to reframe the music video as an object of critique rather than consumption, and it was non-commercial in intent. However, the continued presence of the original music and visuals meant that the transformation was partial rather than complete.

### Nature of the copyrighted work (creative vs. factual?)

The copyrighted work in question is a highly creative, expressive music video, which places it near the core of copyright protection. This factor weighs strongly against fair use for both the raw clips and the commentary version, as courts generally grant stronger protection to artistic works than to factual or informational ones.

### Amount and substantiality used

The five-second clip used a very small portion of the work, favoring fair use under this factor, especially given its brevity. The one-minute clip and the one-minute commentary video used a more substantial portion of the song and video, both quantitatively and qualitatively, which weighs against fair use even though the use was not the entirety of the work.

### Effect on the market for the original

The raw clips, especially the longer one, could plausibly substitute for the original content in short-form contexts, weighing against fair use. The commentary video is less likely to serve as a market substitute, since viewers are not consuming it primarily for the music video itself, but automated enforcement appears to treat any detectable substitution risk as sufficient to trigger blocking regardless of context.

## Gap Analysis

### Legal theory (what copyright law says)

Under copyright law, fair use is a contextual, case-by-case analysis that balances transformation, purpose, amount, and market effect, with no single factor being dispositive. Transformative commentary and criticism are explicitly recognized as paradigmatic fair uses, even when they include portions of the original work.

### Platform policy (what the platform claims to do)

Instagram’s stated policy allows commentary and criticism and provides dispute mechanisms, while emphasizing respect for copyright and rights-holder claims. In theory, users can contest automated detections through appeals or disputes, invoking fair use or permission.

### Actual enforcement (what actually happened)

In practice, enforcement was automated, fast, and largely indifferent to context: both the raw clip and the commentary video were blocked within an hour, while only the extremely short clip avoided detection. This reveals a gap where legal fair use doctrine is subordinated to automated rights-holder enforcement, effectively shifting the burden onto users to dispute claims and privileging platform efficiency and rights-holder protection over nuanced legal analysis.
